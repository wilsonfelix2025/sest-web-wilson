export const environment = {
  production: false,
  staging: true,
  pocoWeb: 'https://pocoweb.petro.intelie.net',
  serverUrl: 'http://homologacao.gtep.civ.puc-rio.br:8000',
  appUrl: 'http://homologacao.gtep.civ.puc-rio.br:8000',
  clientId: 'sestwebdev2',
  clientSecret: 'sestwebdev2'
};
