export const environment = {
  production: true,
  staging: false,
  //pocoWeb: 'https://pocoweb.cenpes.petrobras.com.br',
  pocoWeb: 'https://pocoweb.petro.intelie.net',  
  serverUrl: 'http://homologacao.gtep.civ.puc-rio.br:8009/api',
  appUrl: 'http://homologacao.gtep.civ.puc-rio.br:8009',
  clientId: 'sestwebdev2',
  clientSecret: 'sestwebdev2'
};
