export enum TipoConversao {
    PressãoAbsoluta = 'pressãoAbsoluta',
    PressãoManométrica = 'pressãoManométrica',
    Gradiente = 'Gradiente',
}