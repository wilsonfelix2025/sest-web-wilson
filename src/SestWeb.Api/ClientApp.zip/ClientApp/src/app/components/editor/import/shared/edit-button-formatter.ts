export function editButtonFormatter(name: string) {
    return `<i class='button fas fa-edit' style='margin: auto; margin-left: 5px; cursor: pointer;' id='${name}'></i>`
}