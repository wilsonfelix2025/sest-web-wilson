export const FILE_TYPE_PREFIX = 'sesttr';

export const FILE_TYPES: Array<string> = [
  `${FILE_TYPE_PREFIX}.project`,
  `${FILE_TYPE_PREFIX}.monitoring`,
  `${FILE_TYPE_PREFIX}.retroanalysis`,
];
