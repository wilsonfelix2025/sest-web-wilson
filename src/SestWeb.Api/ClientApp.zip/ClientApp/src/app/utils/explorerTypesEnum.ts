export enum E_TYPES {
    OpUnit,
    OilField,
    Well,
    Case
}